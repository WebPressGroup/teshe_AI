# DealShield

## Overview

This is a full-stack web application called "DealShield" — an AI-powered car-buying negotiation assistant. Users paste their dealership notes, quotes, or upload images of deal sheets, and the app uses OpenAI to analyze the deal, detect manipulative dealership tactics, compute deal math (OTD price, APR, total cost), and provide actionable counter-scripts and next steps.

The app has two main pages:
- **Home** (`/`): Input form where users enter deal notes, add dealer quotes, and upload images
- **Dashboard** (`/dashboard`): Displays the AI analysis results including detected tactics, deal math comparison, action plans, red flags, and a verdict

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side router)
- **State Management**: TanStack React Query for server state (data fetching, caching, mutations)
- **UI Components**: Shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming, dark mode by default with a security/defense color scheme (dark slate/zinc backgrounds, red/orange for warnings, emerald/green for safe indicators, blue for information)
- **Animations**: Framer Motion for card transitions and dashboard animations
- **Fonts**: Outfit (display), DM Sans (body), JetBrains Mono (monospace)
- **Build Tool**: Vite with React plugin
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend
- **Runtime**: Node.js with Express 5
- **Language**: TypeScript, executed via `tsx`
- **API Pattern**: JSON REST API under `/api/*` prefix
- **AI Integration**: OpenAI API (via Replit AI Integrations environment variables `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`) — sends a detailed system prompt instructing the model to return structured JSON with tactics, deal math, action plans, and scripts
- **API Contract**: Shared route definitions in `shared/routes.ts` define method, path, input schema, and response schemas using Zod — used by both client and server for validation

### Shared Layer (`shared/`)
- **Schema**: `shared/schema.ts` defines Drizzle ORM table schemas and Zod validation schemas shared between client and server
- **Routes**: `shared/routes.ts` defines the API contract (paths, methods, input/output schemas) used by both sides
- **Models**: `shared/models/chat.ts` defines conversation and message schemas for the voice chat feature

### Replit Integrations (`server/replit_integrations/` and `client/replit_integrations/`)
Pre-built integration modules for:
- **Chat**: Text-based conversation CRUD with OpenAI streaming
- **Audio/Voice**: Voice recording, speech-to-text, text-to-speech, and streaming voice responses using AudioWorklet
- **Image**: Image generation via `gpt-image-1`
- **Batch**: Batch processing utility with rate limiting and retries (`p-limit`, `p-retry`)

These integrations provide additional capabilities beyond the core deal analysis feature.

### Data Storage
- **Database**: PostgreSQL via `DATABASE_URL` environment variable
- **ORM**: Drizzle ORM with `drizzle-zod` for schema-to-Zod conversion
- **Connection**: `pg` Pool in `server/db.ts`
- **Schema Push**: `npm run db:push` uses `drizzle-kit push` to sync schema to database
- **Key Tables**:
  - `analyses` — stores raw input, image URLs, and structured AI analysis results (JSONB)
  - `conversations` — chat conversation metadata
  - `messages` — individual chat messages linked to conversations

### Build & Deployment
- **Dev**: `npm run dev` — runs Express server with Vite middleware for HMR
- **Build**: `npm run build` — Vite builds the client to `dist/public`, esbuild bundles the server to `dist/index.cjs`
- **Production**: `npm start` — serves the pre-built static files and API from the bundled server
- The build script bundles specific server dependencies (listed in an allowlist) to reduce cold start times

### Key API Endpoints
- `POST /api/analyze` — Accepts deal notes/images, sends to OpenAI with the Defense Coach system prompt, stores and returns structured analysis
- `GET /api/history` — Returns all past analyses
- Conversation CRUD routes from chat/audio integrations (`/api/conversations/*`)

## External Dependencies

### Required Services
- **PostgreSQL Database**: Required. Connection via `DATABASE_URL` environment variable. Used for storing analyses, conversations, and messages.
- **OpenAI API** (via Replit AI Integrations): Required for core functionality. Uses `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables. Powers the deal analysis, chat, voice, and image features.

### Key NPM Packages
- `drizzle-orm` + `drizzle-kit` — Database ORM and migration tooling
- `openai` — OpenAI API client
- `express` v5 — HTTP server
- `@tanstack/react-query` — Client-side data fetching
- `framer-motion` — Animations
- `zod` + `drizzle-zod` — Runtime validation
- `wouter` — Client-side routing
- `recharts` — Charting (available via shadcn chart component)
- `vaul` — Drawer component
- `p-limit` + `p-retry` — Batch processing utilities