import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { analyzeRequestSchema } from "@shared/schema";
import OpenAI from "openai";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pdf = require("pdf-parse");
import Tesseract from "tesseract.js";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const SYSTEM_PROMPT = `You are "DealShield", a world-class AI car-buying negotiation specialist. Your primary directive is to serve as the buyer's high-stakes defense coach, neutralizing dealership manipulation tactics in real-time.

EVALUATION MODEL (Critical Red Flags):
Assess the situation across 4 dimensions (0-100 scale):
1) Information Control (0–30): Are key numbers (OTD, APR, term, fees) withheld or summarized? Is the dealer controlling the metrics discussed?
2) Decision Autonomy (0–20): Is the user being rushed or pressured? Are options framed to reduce comparison time?
3) Cost Visibility vs Reality (0–30): Is a "comfort metric" (monthly payment) emphasized while total cost variables change? Is there risk of term extension or hidden fees?
4) Verifiability (0–20): Can the deal be reconstructed independently? Is there a written itemized breakdown?

SCORING:
- Total Risk Score = sum of the four dimensions.
- Trigger "CRITICAL RED FLAGS DETECTED" if Risk Score ≥ 70.

GOALS:
1) DEEP TACTICAL ANALYSIS: Analyze text and images for deceptive patterns and psychological pressure points.
2) MATHEMATICAL VERIFICATION: Compute the real OTD price, total interest, and effective APR. Identify "payment packing".
3) STRATEGIC COUNTER-PLAY: Provide specific, assertive action plans and scripts.
4) RISK QUANTIFICATION: Assign a risk level (Normal, Caution, High Risk, CRITICAL) based on the scoring logic.

OUTPUT FORMAT (STRICT JSON ONLY):
Return a single JSON object with these keys:
{
  "critical_red_flags": boolean,
  "risk_score": number (0-100),
  "risk_level": "Normal" | "Caution" | "High Risk" | "CRITICAL",
  "drivers": ["top 3 reasons why the risk is at this level"],
  "tactics_detected": [
    {
      "name": "string",
      "confidence": 0-100,
      "what_it_means": "psychological intent",
      "why_dealers_use_it": "sales goal",
      "risk_to_buyer": "financial impact"
    }
  ],
  "missing_inputs": ["exact items needed: OTD price, APR, term, fees, trade payoff, add-ons list"],
  "deal_math": {
    "vehicle_A": { "label": "string", "otd_price": number_or_null, "apr": number_or_null, "term_months": number_or_null, "down_payment": number_or_null, "trade_in_value": number_or_null, "trade_in_payoff": number_or_null, "monthly_payment": number_or_null, "total_cost_estimate": number_or_null, "notes": "analysis" },
    "vehicle_B": { "label": "string", "otd_price": number_or_null, "apr": number_or_null, "term_months": number_or_null, "down_payment": number_or_null, "trade_in_value": number_or_null, "trade_in_payoff": number_or_null, "monthly_payment": number_or_null, "total_cost_estimate": number_or_null, "notes": "analysis" },
    "comparison_summary": "strategic overview"
  },
  "next_best_actions": [
    { "priority": number, "action": "string", "why": "string" }
  ],
  "next_steps": ["3-5 action steps starting with 'Pause and request full written breakdown' if critical"],
  "questions_to_ask": ["up to 6 targeted questions based on missing info"],
  "scripts_to_say": {
    "stop_payment_talk": ["string"],
    "refocus_on_otd": ["string"],
    "refuse_add_ons": ["string"],
    "walk_away": ["string"]
  },
  "red_flags": ["string"],
  "confidence_score": 0-100,
  "one_sentence_verdict": "string (professional judgment)"
}`;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.analysis.create.path, async (req, res) => {
    try {
      const input = analyzeRequestSchema.parse(req.body);
      
      const content: any[] = [
        { type: "text", text: `Buyer notes: ${input.notes || "None provided"}` },
        { type: "text", text: `Dealer quotes: ${JSON.stringify(input.dealerQuotes || [])}` },
      ];

      if (input.images && input.images.length > 0) {
        input.images.forEach(img => {
          content.push({
            type: "image_url",
            image_url: { url: `data:image/jpeg;base64,${img}` }
          });
        });
      }

      if (input.audio) {
        try {
          // Transcribe the audio using OpenAI
          const transcription = await openai.audio.transcriptions.create({
            file: await (async () => {
              const buffer = Buffer.from(input.audio!, "base64");
              // Create a File-like object from buffer for the OpenAI SDK
              const file = new File([buffer], "voicemail.mp3", { type: "audio/mpeg" });
              return file;
            })(),
            model: "gpt-4o-mini-transcribe",
          });
          content.push({ type: "text", text: `Voicemail Transcript: ${transcription.text}` });
        } catch (transcriptionError) {
          console.error("Transcription failed:", transcriptionError);
          // Fallback or handle error - here we'll just skip adding the transcript if it fails
        }
      }

      const completion = await openai.chat.completions.create({
        model: "gpt-5.1", // Uses gpt-5.1 which is multimodal
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: content }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(completion.choices[0].message.content || "{}");
      
      // Store the analysis
      const analysis = await storage.createAnalysis({
        rawInput: input.notes || "Image Analysis",
        structuredData: result,
        imageUrls: [], // In a real app we'd upload these to storage first
      });

      res.json(analysis);

    } catch (error: any) {
      console.error("Analysis failed:", error);
      res.status(500).json({ 
        message: "Failed to analyze deal. Please try again." 
      });
    }
  });

  app.get(api.analysis.history.path, async (req, res) => {
    const history = await storage.getAnalyses();
    res.json(history);
  });

  app.post("/api/extract-text", async (req, res) => {
    try {
      const { file, type, name } = req.body;
      const buffer = Buffer.from(file, "base64");
      let text = "";

      if (type === "application/pdf") {
        const data = await pdf(buffer);
        text = data.text;
      } else if (type.startsWith("image/")) {
        const { data: { text: ocrText } } = await Tesseract.recognize(buffer);
        text = ocrText;
      } else if (type === "text/plain") {
        text = buffer.toString("utf-8");
      }

      res.json({ text });
    } catch (error) {
      console.error("Extraction error:", error);
      res.status(500).json({ message: "Failed to extract text from file" });
    }
  });

  return httpServer;
}
