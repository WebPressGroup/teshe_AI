import { db } from "./db";
import { analyses, type InsertAnalysis, type Analysis } from "@shared/schema";

export interface IStorage {
  createAnalysis(analysis: InsertAnalysis): Promise<Analysis>;
  getAnalyses(): Promise<Analysis[]>;
}

export class DatabaseStorage implements IStorage {
  async createAnalysis(analysis: InsertAnalysis): Promise<Analysis> {
    const [created] = await db.insert(analyses).values(analysis).returning();
    return created;
  }

  async getAnalyses(): Promise<Analysis[]> {
    return await db.select().from(analyses);
  }
}

export const storage = new DatabaseStorage();
