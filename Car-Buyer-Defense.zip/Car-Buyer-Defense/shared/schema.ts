
import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// === TABLE DEFINITIONS ===

// Store analysis results and chat history
export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  userId: text("user_id"), // Optional: for future auth
  rawInput: text("raw_input").notNull(),
  imageUrls: jsonb("image_urls").$type<string[]>().default([]),
  structuredData: jsonb("structured_data").$type<{
    critical_red_flags?: boolean;
    risk_score?: number;
    risk_level?: "Normal" | "Caution" | "High Risk" | "CRITICAL";
    drivers?: string[];
    next_steps?: string[];
    questions_to_ask?: string[];
    tactics_detected: Array<{
      name: string;
      confidence: number;
      what_it_means: string;
      why_dealers_use_it: string;
      risk_to_buyer: string;
    }>;
    missing_inputs: string[];
    deal_math: {
      vehicle_A: any;
      vehicle_B: any;
      comparison_summary: string;
    };
    next_best_actions: Array<{
      priority: number;
      action: string;
      why: string;
    }>;
    scripts_to_say: Record<string, string[]>;
    red_flags: string[];
    confidence_score: number;
    one_sentence_verdict: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// For voice chat (blueprint integration)
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

// === SCHEMAS ===

export const insertAnalysisSchema = createInsertSchema(analyses).omit({ 
  id: true, 
  createdAt: true 
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

// === EXPLICIT API TYPES ===

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;

// Request type for analyzing dealer communication
export const analyzeRequestSchema = z.object({
  notes: z.string().optional(),
  dealerQuotes: z.array(z.string()).optional(),
  vehicleInfo: z.record(z.any()).optional(),
  images: z.array(z.string()).optional(), // Base64 images
  audio: z.string().optional(), // Base64 audio file
});

export type AnalyzeRequest = z.infer<typeof analyzeRequestSchema>;

// Response type matching the "Car Buyer Defense Coach" JSON structure
export type AnalysisResponse = NonNullable<Analysis['structuredData']>;
