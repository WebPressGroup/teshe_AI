## Packages
framer-motion | Smooth animations for dashboard cards and transitions
lucide-react | Beautiful icons for tactics, warnings, and actions
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}

Colors should focus on a "Defense/Security" theme:
- Dark backgrounds (slate/zinc)
- High contrast text
- Accents:
  - Warning/Danger: Red/Orange (for tactics/red flags)
  - Success/Safe: Emerald/Green (for good deal math)
  - Information/Neutral: Blue/Indigo (for general UI)
