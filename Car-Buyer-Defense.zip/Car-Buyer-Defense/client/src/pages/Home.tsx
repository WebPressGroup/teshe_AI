import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useAnalysis } from "@/hooks/use-analysis";
import { AnalyzeRequest } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";
import logoImg from "@/assets/logo.png";
import { 
  CarFront, 
  MessageSquareText, 
  Sparkles, 
  Loader2, 
  ChevronRight,
  ShieldCheck,
  Quote,
  Image as ImageIcon,
  Upload,
  X,
  Camera,
  RotateCcw
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Home() {
  const [location, setLocation] = useLocation();
  const { analyzeAsync, isAnalyzing } = useAnalysis();
  
  const [notes, setNotes] = useState("");
  const [quoteInput, setQuoteInput] = useState("");
  const [quotes, setQuotes] = useState<string[]>([]);
  const [images, setImages] = useState<string[]>([]);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    for (const file of Array.from(files)) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = (reader.result as string).split(',')[1];
        
        // Add to images if it's an image for analysis
        if (file.type.startsWith('image/')) {
          setImages(prev => [...prev, base64].slice(-5));
        }

        // Extract text from document
        try {
          const response = await fetch('/api/extract-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              file: base64,
              type: file.type,
              name: file.name
            })
          });
          
          if (response.ok) {
            const { text } = await response.json();
            if (text) {
              setNotes(prev => {
                const newNotes = prev ? `${prev}\n\n--- Extracted from ${file.name} ---\n${text}` : text;
                return newNotes;
              });
            }
          }
        } catch (err) {
          console.error("Extraction failed:", err);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleAddQuote = () => {
    if (quoteInput.trim()) {
      setQuotes([...quotes, quoteInput.trim()]);
      setQuoteInput("");
    }
  };

  const handleAnalyze = async () => {
    if (!notes.trim()) return;

    try {
      const request: AnalyzeRequest = {
        notes,
        dealerQuotes: quotes.length > 0 ? quotes : undefined,
        images: images.length > 0 ? images : undefined,
      };

      const result = await analyzeAsync(request);
      setLocation("/dashboard");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4 md:p-8 relative overflow-hidden">
      {/* Background decoration - Professional Palette */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-secondary/5 rounded-full blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl w-full space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center mb-4 p-4 rounded-full bg-background">
            <ShieldCheck className="w-24 h-24 text-primary" />
          </div>
          <h1 className="text-5xl md:text-6xl font-display font-bold tracking-tight text-primary">
            DealShield
          </h1>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto leading-relaxed">
            Your high-stakes AI negotiator. Powered by advanced behavioral logic to detect dealership manipulation, verify deal math, and seize control of the negotiation.
          </p>
        </div>

        <Card className="border-border bg-card shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquareText className="w-5 h-5 text-primary" />
              Deal Details
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Paste emails, text messages, or your own notes from the dealership.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-foreground/90">Notes / Transcript</Label>
              <Textarea 
                id="notes" 
                placeholder="e.g. Dealer said they can't lower the price but can throw in a warranty. They quoted me $450/mo for 72 months..."
                className="min-h-[200px] bg-muted/50 border-border focus:border-primary/50 text-base resize-none"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <div className="space-y-4 pt-4 border-t border-border">
              <Label className="flex items-center gap-2 text-foreground/90">
                <ImageIcon className="w-4 h-4 text-primary" />
                Upload Dealer Documents or Photos (Optional)
              </Label>
              
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-border rounded-lg p-10 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-muted/30 transition-all group"
              >
                <Upload className="w-10 h-10 text-muted-foreground mb-3 group-hover:text-primary" />
                <p className="text-base font-medium text-foreground/90 text-center">Upload Files</p>
                <p className="text-sm text-muted-foreground text-center mt-1">Images, PDFs, or text documents</p>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*,.pdf,.txt,.doc,.docx"
                  multiple
                  className="hidden" 
                />
              </div>

              {images.length > 0 && (
                <div className="flex flex-wrap gap-4 mt-4">
                  {images.map((img, idx) => (
                    <div key={idx} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border group">
                      <img 
                        src={`data:image/jpeg;base64,${img}`} 
                        className="w-full h-full object-cover"
                        alt={`Upload ${idx + 1}`} 
                      />
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          removeImage(idx);
                        }}
                        className="absolute top-1 right-1 bg-background/80 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-4 pt-4 border-t border-border">
              <Label className="flex items-center gap-2 text-foreground/90">
                <Quote className="w-4 h-4 text-primary" />
                Specific Dealer Quotes (Optional)
              </Label>
              <div className="flex gap-2">
                <Input 
                  placeholder="e.g. 'I have to talk to my manager'"
                  value={quoteInput}
                  onChange={(e) => setQuoteInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddQuote()}
                  className="bg-muted/50 border-border"
                />
                <Button 
                  type="button" 
                  variant="secondary" 
                  onClick={handleAddQuote}
                  disabled={!quoteInput.trim()}
                >
                  Add
                </Button>
              </div>
              
              {quotes.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {quotes.map((q, idx) => (
                    <span 
                      key={idx} 
                      className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-secondary/10 text-secondary border border-secondary/20"
                    >
                      "{q}"
                      <button 
                        onClick={() => setQuotes(quotes.filter((_, i) => i !== idx))}
                        className="ml-2 hover:text-white"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <Button 
              className="w-full h-14 text-lg font-semibold shadow-lg shadow-primary/25 mt-4"
              onClick={handleAnalyze}
              disabled={isAnalyzing || !notes.trim()}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing Deal Structure...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Analyze My Deal
                  <ChevronRight className="w-5 h-5 ml-2 opacity-50" />
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
          <div className="flex flex-col items-center text-center space-y-3 p-4">
            <div className="p-3 rounded-full bg-destructive/10 text-destructive">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-foreground">Advanced AI Logic</h3>
            <p className="text-sm text-muted-foreground">Neural analysis of psychological tactics and behavioral sales pressure.</p>
          </div>
          <div className="flex flex-col items-center text-center space-y-3 p-4">
            <div className="p-3 rounded-full bg-primary/10 text-primary">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-foreground">Multimodal Analysis</h3>
            <p className="text-sm text-muted-foreground">Upload buyer's orders or deal sheets. Our AI parses math errors instantly.</p>
          </div>
          <div className="flex flex-col items-center text-center space-y-3 p-4">
            <div className="p-3 rounded-full bg-secondary/10 text-secondary">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-foreground">Tactical Scripts</h3>
            <p className="text-sm text-muted-foreground">Get surgical counter-scripts designed by veteran negotiators.</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
