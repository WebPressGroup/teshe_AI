import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAnalysis } from "@/hooks/use-analysis";
import { VerdictCard } from "@/components/VerdictCard";
import { TacticCard } from "@/components/TacticCard";
import { DealMath } from "@/components/DealMath";
import { ActionPlan } from "@/components/ActionPlan";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ArrowLeft, 
  AlertOctagon, 
  LayoutDashboard, 
  RefreshCcw,
  ShieldCheck
} from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [_, setLocation] = useLocation();
  const { history, isLoadingHistory } = useAnalysis();

  // Get the most recent analysis
  // In a full app, we would use a route param like /dashboard/:id
  const currentAnalysis = history?.[0]; 
  const result = currentAnalysis?.structuredData;

  const riskColors: Record<string, string> = {
    "Normal": "text-green-500 bg-green-500/10 border-green-500/20",
    "Caution": "text-yellow-500 bg-yellow-500/10 border-yellow-500/20",
    "High Risk": "text-orange-500 bg-orange-500/10 border-orange-500/20",
    "CRITICAL": "text-red-500 bg-red-500/10 border-red-500/20"
  };

  const currentRiskColor = result?.risk_level ? riskColors[result.risk_level] : "text-muted-foreground bg-muted";

  if (isLoadingHistory) {
    return <DashboardLoading />;
  }

  if (!result) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center space-y-4 text-center p-4">
        <h2 className="text-2xl font-bold">No Analysis Found</h2>
        <p className="text-muted-foreground">Start by entering your deal details.</p>
        <Button onClick={() => setLocation("/")}>Go Home</Button>
      </div>
    );
  }

  const hasRedFlags = result.red_flags && result.red_flags.length > 0;

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-8 pb-20">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/" className="p-2 rounded-full hover:bg-muted transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </Link>
            <div>
              <h1 className="text-2xl font-display font-bold flex items-center gap-2">
                <LayoutDashboard className="w-6 h-6 text-primary" />
                Analysis Dashboard
              </h1>
              <p className="text-sm text-muted-foreground">
                Generated {new Date(currentAnalysis.createdAt!).toLocaleDateString()} at {new Date(currentAnalysis.createdAt!).toLocaleTimeString()}
              </p>
            </div>
          </div>
          
          <Button variant="outline" onClick={() => setLocation("/")} className="gap-2 border-white/10 hover:bg-white/5">
            <RefreshCcw className="w-4 h-4" />
            New Analysis
          </Button>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          
          <div className="space-y-8">
            <VerdictCard 
              verdict={result.one_sentence_verdict}
              confidence={result.confidence_score}
            />

            {/* Advanced Risk Scoring Module */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`rounded-xl border p-6 backdrop-blur-sm shadow-lg ${currentRiskColor}`}
            >
              <div className="flex flex-col gap-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-background/20">
                      <AlertOctagon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold tracking-tight">Risk Assessment: {result.risk_level || "Analyzing..."}</h3>
                      <p className="text-sm opacity-80">Advanced Behavioral Risk Score: {result.risk_score || 0}/100</p>
                    </div>
                  </div>
                  {result.risk_score !== undefined && (
                    <div className="text-3xl font-black">{result.risk_score}</div>
                  )}
                </div>

                {result.drivers && result.drivers.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="text-sm font-bold uppercase tracking-wider opacity-70">Primary Risk Drivers</h4>
                    <div className="grid grid-cols-1 gap-2">
                      {result.drivers.map((driver, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm font-medium p-2 rounded-md bg-background/10">
                          <span className="w-1.5 h-1.5 rounded-full bg-current" />
                          {driver}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {result.questions_to_ask && result.questions_to_ask.length > 0 && (
                  <div className="space-y-3 p-4 rounded-lg bg-background/10 border border-current/10">
                    <h4 className="text-sm font-bold uppercase tracking-wider opacity-70">Critical Questions to Ask</h4>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                      {result.questions_to_ask.map((q, idx) => (
                        <li key={idx} className="text-sm italic opacity-90 list-disc list-inside ml-2">{q}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </motion.div>

            {hasRedFlags && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-xl border border-red-500/20 bg-red-500/5 p-6 backdrop-blur-sm shadow-lg shadow-red-500/5"
              >
                <div className="flex items-start gap-4">
                  <div className="p-2.5 rounded-lg bg-red-500/10 shrink-0">
                    <AlertOctagon className="w-6 h-6 text-red-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-red-500 mb-3 tracking-tight">Critical Red Flags Detected</h3>
                    <ul className="space-y-2.5">
                      {result.red_flags.map((flag, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-foreground/90 leading-relaxed">
                          <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                          {flag}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="space-y-6">
              <div className="flex items-center justify-between px-2">
                <h2 className="text-xl font-bold font-display tracking-tight">Tactics Detected</h2>
                <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">
                  {result.tactics_detected.length} Identified
                </span>
              </div>
              <div className="space-y-4">
                {result.tactics_detected.map((tactic, idx) => (
                  <TacticCard 
                    key={idx}
                    name={tactic.name}
                    confidence={tactic.confidence}
                    whatItMeans={tactic.what_it_means}
                    whyUsed={tactic.why_dealers_use_it}
                    risk={tactic.risk_to_buyer}
                    index={idx}
                  />
                ))}
                {result.tactics_detected.length === 0 && (
                  <div className="p-6 rounded-xl border border-dashed border-white/10 text-center text-muted-foreground">
                    No deceptive tactics detected.
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="space-y-6">
              <h2 className="text-xl font-bold font-display px-2 tracking-tight flex items-center gap-2">
                <RefreshCcw className="w-5 h-5 text-teal-500" />
                Deal Math Comparison
              </h2>
              <DealMath 
                math={result.deal_math}
                missingInputs={result.missing_inputs}
              />
            </div>

            <div className="space-y-6">
              <h2 className="text-xl font-bold font-display px-2 tracking-tight flex items-center gap-2">
                <ArrowLeft className="w-5 h-5 text-primary rotate-180" />
                Your Defensive Action Plan
              </h2>
              <ActionPlan 
                actions={result.next_best_actions}
                scripts={result.scripts_to_say}
              />
            </div>

            {result.next_steps && result.next_steps.length > 0 && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold font-display px-2 tracking-tight flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-green-500" />
                  Restoring Control: Next Steps
                </h2>
                <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
                  <div className="space-y-4">
                    {result.next_steps.map((step, idx) => (
                      <div key={idx} className="flex gap-4 items-start">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                          {idx + 1}
                        </div>
                        <p className="text-foreground/90 leading-relaxed font-medium">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function DashboardLoading() {
  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Skeleton className="w-10 h-10 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="w-48 h-8" />
            <Skeleton className="w-32 h-4" />
          </div>
        </div>
        <Skeleton className="w-full h-48 rounded-2xl" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Skeleton className="h-[600px] rounded-xl" />
          <Skeleton className="h-[600px] rounded-xl" />
          <Skeleton className="h-[600px] rounded-xl" />
        </div>
      </div>
    </div>
  );
}
