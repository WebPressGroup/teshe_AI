import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { AnalyzeRequest, AnalysisResponse, Analysis } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useAnalysis() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const analyzeMutation = useMutation({
    mutationFn: async (data: AnalyzeRequest) => {
      // Validate input before sending using the shared schema
      const validatedInput = api.analysis.create.input.parse(data);
      
      const res = await fetch(api.analysis.create.path, {
        method: api.analysis.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedInput),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.analysis.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 500) {
          const error = api.analysis.create.responses[500].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to analyze deal");
      }

      return api.analysis.create.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({
        title: "Analysis Complete",
        description: "Your deal has been analyzed successfully.",
      });
      // Invalidate history query to show new analysis in list
      queryClient.invalidateQueries({ queryKey: [api.analysis.history.path] });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const historyQuery = useQuery({
    queryKey: [api.analysis.history.path],
    queryFn: async () => {
      const res = await fetch(api.analysis.history.path);
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.analysis.history.responses[200].parse(await res.json());
    },
  });

  return {
    analyze: analyzeMutation.mutate,
    analyzeAsync: analyzeMutation.mutateAsync,
    isAnalyzing: analyzeMutation.isPending,
    analysisResult: analyzeMutation.data,
    history: historyQuery.data,
    isLoadingHistory: historyQuery.isLoading,
  };
}
