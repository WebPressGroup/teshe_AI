import { AlertCircle, Calculator } from "lucide-react";

interface DealMathProps {
  math: {
    vehicle_A: any;
    vehicle_B: any;
    comparison_summary: string;
  };
  missingInputs: string[];
}

export function DealMath({ math, missingInputs }: DealMathProps) {
  // Helper to safely display currency
  const formatMoney = (val: any) => {
    if (typeof val === 'number') return `$${val.toLocaleString()}`;
    if (typeof val === 'string' && val.includes('$')) return val;
    if (!val) return '—';
    return val;
  };

  const renderVehicleColumn = (vehicle: any, title: string) => {
    if (!vehicle) return null;
    return (
      <div className="space-y-4">
        <h4 className="font-bold text-center text-lg text-primary">{title}</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between py-2 border-b border-white/5">
            <span className="text-muted-foreground">MSRP/Price</span>
            <span className="font-mono">{formatMoney(vehicle.price || vehicle.msrp)}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-white/5">
            <span className="text-muted-foreground">Monthly Pmt</span>
            <span className="font-mono text-foreground font-bold">{formatMoney(vehicle.monthly_payment)}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-white/5">
            <span className="text-muted-foreground">Down Pmt</span>
            <span className="font-mono">{formatMoney(vehicle.down_payment)}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-white/5">
            <span className="text-muted-foreground">Term</span>
            <span className="font-mono">{vehicle.term || '—'} months</span>
          </div>
          <div className="flex justify-between py-2 border-b border-white/5">
            <span className="text-muted-foreground">APR</span>
            <span className="font-mono">{vehicle.apr || '—'}%</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 h-full">
      <div className="bg-card rounded-xl border border-white/5 p-6 h-full">
        <div className="flex items-center gap-2 mb-6">
          <Calculator className="w-5 h-5 text-indigo-400" />
          <h3 className="text-lg font-display font-bold">Deal Mathematics</h3>
        </div>

        {missingInputs.length > 0 && (
          <div className="mb-6 p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
            <div className="flex gap-2 text-orange-400 mb-2">
              <AlertCircle className="w-4 h-4 mt-0.5" />
              <span className="text-xs font-bold uppercase tracking-wide">Missing Inputs</span>
            </div>
            <p className="text-sm text-muted-foreground mb-2">
              To get accurate math, ask the dealer for:
            </p>
            <div className="flex flex-wrap gap-2">
              {missingInputs.map((input, idx) => (
                <span key={idx} className="text-xs px-2 py-1 rounded bg-background border border-white/10 text-foreground font-mono">
                  {input}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {renderVehicleColumn(math.vehicle_A, "Vehicle A")}
          {math.vehicle_B && renderVehicleColumn(math.vehicle_B, "Vehicle B")}
        </div>

        {math.comparison_summary && (
          <div className="mt-8 pt-6 border-t border-white/5">
            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wide mb-2">Comparison Analysis</h4>
            <p className="text-sm text-foreground/90 leading-relaxed">
              {math.comparison_summary}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
