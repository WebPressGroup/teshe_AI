import { AlertTriangle, Info, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface TacticProps {
  name: string;
  confidence: number;
  whatItMeans: string;
  whyUsed: string;
  risk: string;
  index: number;
}

export function TacticCard({ name, confidence, whatItMeans, whyUsed, risk, index }: TacticProps) {
  const isHighRisk = risk.toLowerCase().includes("high") || risk.toLowerCase().includes("money");

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-xl border border-white/5 bg-card hover:bg-card/80 transition-all duration-300 hover:shadow-xl hover:border-primary/20"
    >
      <div className={`absolute top-0 left-0 w-1 h-full ${isHighRisk ? 'bg-red-500' : 'bg-orange-500'}`} />
      
      <div className="p-5 pl-7">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="font-display font-bold text-lg text-foreground group-hover:text-primary transition-colors">
              {name}
            </h3>
            {isHighRisk && (
              <span className="inline-flex items-center rounded-full bg-red-500/10 px-2 py-0.5 text-xs font-medium text-red-500 ring-1 ring-inset ring-red-500/20">
                High Risk
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-md font-mono">
            <span>{confidence}%</span>
            <span>Match</span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          {whatItMeans}
        </p>

        <div className="grid grid-cols-1 gap-3 pt-4 border-t border-white/5">
          <div className="flex gap-2">
            <Info className="w-4 h-4 text-primary mt-0.5 shrink-0" />
            <div className="text-xs">
              <span className="font-semibold text-foreground">Why they use it: </span>
              <span className="text-muted-foreground">{whyUsed}</span>
            </div>
          </div>
          
          <div className="flex gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
            <div className="text-xs">
              <span className="font-semibold text-foreground">Risk to you: </span>
              <span className="text-red-300/80">{risk}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
