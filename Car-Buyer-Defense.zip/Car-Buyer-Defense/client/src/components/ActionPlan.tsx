import { 
  CheckCircle2, 
  MessageSquare, 
  ArrowRight,
  ChevronDown
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";

interface ActionPlanProps {
  actions: Array<{ priority: number; action: string; why: string }>;
  scripts: Record<string, string[]>;
}

export function ActionPlan({ actions, scripts }: ActionPlanProps) {
  return (
    <div className="space-y-8">
      {/* Priority Actions */}
      <div className="space-y-4">
        <h3 className="text-lg font-display font-bold flex items-center gap-2 text-foreground">
          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
          Next Best Actions
        </h3>
        <div className="space-y-3">
          {actions.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="flex gap-4 p-4 rounded-xl bg-card border border-white/5 hover:border-primary/20 transition-colors"
            >
              <div className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold font-mono text-sm">
                {idx + 1}
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">{item.action}</h4>
                <p className="text-sm text-muted-foreground">{item.why}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Scripts */}
      <div className="space-y-4">
        <h3 className="text-lg font-display font-bold flex items-center gap-2 text-foreground">
          <MessageSquare className="w-5 h-5 text-blue-500" />
          Scripts & Responses
        </h3>
        
        <Accordion type="single" collapsible className="w-full space-y-2">
          {Object.entries(scripts).map(([category, lines], idx) => (
            <AccordionItem 
              key={idx} 
              value={`item-${idx}`} 
              className="border border-white/5 rounded-xl bg-card px-4 data-[state=open]:border-primary/20 transition-colors"
            >
              <AccordionTrigger className="hover:no-underline py-4">
                <span className="font-medium text-left">{category}</span>
              </AccordionTrigger>
              <AccordionContent className="pb-4">
                <div className="space-y-3">
                  {lines.map((line, lineIdx) => (
                    <div key={lineIdx} className="flex gap-3 p-3 rounded-lg bg-muted/30 text-sm">
                      <ArrowRight className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      <p className="text-muted-foreground italic">"{line}"</p>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}
