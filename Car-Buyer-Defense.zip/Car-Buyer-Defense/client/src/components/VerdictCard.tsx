import { ShieldCheck, ShieldAlert, BadgeCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface VerdictCardProps {
  verdict: string;
  confidence: number;
  className?: string;
}

export function VerdictCard({ verdict, confidence, className }: VerdictCardProps) {
  // Determine variant based on simple sentiment analysis of verdict or just generic
  // In a real app, the API might return a "sentiment" field.
  // For now, we'll assume high confidence + positive words = good, else caution.
  
  const isHighConfidence = confidence > 80;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={cn(
        "relative overflow-hidden rounded-2xl border p-8 shadow-2xl",
        "bg-gradient-to-br from-card to-card/50",
        className
      )}
    >
      <div className="absolute top-0 right-0 p-4 opacity-10">
        <ShieldCheck className="h-64 w-64" />
      </div>

      <div className="relative z-10 flex flex-col md:flex-row gap-8 items-start md:items-center justify-between">
        <div className="space-y-4 max-w-2xl">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center justify-center p-2 rounded-lg bg-primary/10 text-primary">
              <BadgeCheck className="w-6 h-6" />
            </span>
            <h2 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
              Coach's Verdict
            </h2>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-display font-bold leading-tight text-white">
            "{verdict}"
          </h1>
        </div>

        <div className="flex flex-col items-center justify-center p-6 rounded-xl bg-background/50 border border-white/5 backdrop-blur-sm min-w-[160px]">
          <div className="relative flex items-center justify-center">
            <svg className="w-24 h-24 transform -rotate-90">
              <circle
                cx="48"
                cy="48"
                r="40"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                className="text-muted/20"
              />
              <circle
                cx="48"
                cy="48"
                r="40"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={251.2}
                strokeDashoffset={251.2 - (251.2 * confidence) / 100}
                className={cn(
                  "text-primary transition-all duration-1000 ease-out",
                  confidence < 50 ? "text-red-500" : confidence < 75 ? "text-yellow-500" : "text-emerald-500"
                )}
              />
            </svg>
            <span className="absolute text-2xl font-bold font-mono">
              {confidence}%
            </span>
          </div>
          <span className="mt-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Confidence
          </span>
        </div>
      </div>
    </motion.div>
  );
}
